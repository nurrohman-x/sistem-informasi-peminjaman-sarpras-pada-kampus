@include('front.layouts.header')
@include('front.layouts.navbar')
@include('front.layouts.sidebar')
@yield('content')
@include('front.layouts.footer')

<!-- @include('sweetalert::alert') -->