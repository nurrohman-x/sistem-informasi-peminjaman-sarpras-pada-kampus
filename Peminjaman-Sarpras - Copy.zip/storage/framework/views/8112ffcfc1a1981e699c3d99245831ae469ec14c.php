
<?php $__env->startPush('title', 'Validasi | Sudah'); ?>
<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2>Sesudah Validasi</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="#!">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Pages</span></li>
                <li><span>Validasi</span></li>
                <li><span style="margin-right: 20px;">Sesudah</span></li>
            </ol>

        </div>
    </header>
    <!-- Start page -->
    <section class="panel">
        <header class="panel-heading">
            <div class="panel-actions">
                <a href="#" class="fa fa-caret-down"></a>
                <a href="#" class="fa fa-times"></a>
            </div>

            <h2 class="panel-title">Daftar Persetujuan Permohonan</h2>
        </header>
        <div class="panel-body">
            <table class="table table-bordered table-striped mb-none" id="datatable-default">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Keperluan</th>
                        <th>Tanggal Kegiatan</th>
                        <th>Jumlah</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $setuju; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($data->keperluan); ?></td>
                        <td><?php echo e(date('d F', strtotime( $data->tanggal_start ))); ?> sd. <?php echo e(date('d F Y', strtotime( $data->tanggal_finish ))); ?></td>
                        <td><?php echo e(count($data->draft)); ?></td>
                        <th width="85px">
                            <a href="<?php echo e(route('validasi.show', $data->id)); ?>" class="mr-xs btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="Detail"><i class="fa fa-eye"></i></a>
                            <?php if(Auth::user()->roles == 'KTU' && $data->validasi_koor == 0): ?>
                            <form action="/validasi/<?php echo e($data->id); ?>" method="post" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <input type="hidden" name="sudah_ktu" value="2">
                                <button type="submit" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="Tolak"><i class="fa fa-times"></i></button>
                            </form>
                            <?php elseif(Auth::user()->roles == 'Koordinator' && $data->validasi_bmn == 0): ?>
                            <form action="/validasi/<?php echo e($data->id); ?>" method="post" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <input type="hidden" name="sudah_koor" value="2">
                                <button type="submit" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="Tolak"><i class="fa fa-times"></i></button>
                            </form>
                            <?php elseif(AUth::user()->roles == 'BMN' && $data->status == 0): ?>
                            <form action="/validasi/<?php echo e($data->id); ?>" method="post" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <input type="hidden" name="sudah_bmn" value="2">
                                <button type="submit" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="Tolak"><i class="fa fa-times"></i></button>
                            </form>
                            <?php endif; ?>
                            <!-- <a class="mr-xs btn btn-warning btn-xs"><i class="fa fa-pencil-square-o"></i> Setuju</a> -->
                            <!-- <a href="#notif" class="mr-xs btn btn-info btn-xs modal-with-zoom-anim" id="showModal" data-nama="<?php echo e($data->user->name); ?>" data-keperluan="<?php echo e($data->keperluan); ?>" data-mulai="<?php echo e(date('D, d F Y', strtotime( $data->tanggal_start ))); ?>" data-sampai="<?php echo e(date('D, d F Y', strtotime( $data->tanggal_finish ))); ?>">
                                <i class="fa fa-comments-o"></i>
                                Notif
                            </a> -->
                            <!-- <a class="mr-xs btn btn-danger btn-xs"><i class="fa fa-times"></i> Tolak</a> -->
                        </th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
    <section class="panel">
        <header class="panel-heading">
            <div class="panel-actions">
                <a href="#" class="fa fa-caret-down"></a>
                <a href="#" class="fa fa-times"></a>
            </div>

            <h2 class="panel-title">Daftar Penolakan Permohonan</h2>
        </header>
        <div class="panel-body">
            <table class="table table-bordered table-striped mb-none" id="datatable-default-1">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Keperluan</th>
                        <th>Tanggal Kegiatan</th>
                        <th>Jumlah</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tidak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($data->keperluan); ?></td>
                        <td><?php echo e(date('d F', strtotime( $data->tanggal_start ))); ?> sd. <?php echo e(date('d F Y', strtotime( $data->tanggal_finish ))); ?></td>
                        <td><?php echo e(count($data->draft)); ?></td>
                        <th width="85px">
                            <a href="<?php echo e(route('validasi.show', $data->id)); ?>" class="mr-xs btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="Detail"><i class="fa fa-eye"></i></a>
                            <?php if(Auth::user()->roles == 'KTU' && $data->validasi_koor == 0): ?>
                            <form action="/validasi/<?php echo e($data->id); ?>" method="post" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <input type="hidden" name="sudah_ktu" value="1">
                                <button type="submit" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="Setuju"><i class="fa fa-pencil-square-o"></i></button>
                            </form>
                            <?php elseif(Auth::user()->roles == 'Koordinator' && $data->validasi_bmn == 0): ?>
                            <form action="/validasi/<?php echo e($data->id); ?>" method="post" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <input type="hidden" name="sudah_koor" value="1">
                                <button type="submit" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="Setuju"><i class="fa fa-pencil-square-o"></i></button>
                            </form>
                            <?php elseif(AUth::user()->roles == 'BMN' && $data->status == 0): ?>
                            <form action="/validasi/<?php echo e($data->id); ?>" method="post" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <input type="hidden" name="sudah_bmn" value="1">
                                <button type="submit" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="Setuju"><i class="fa fa-pencil-square-o"></i></button>
                                <!-- <button type="submit" class="mr-xs btn btn-warning btn-xs"><i class="fa fa-pencil-square-o"></i>Setuju</button> -->
                            </form>
                            <?php endif; ?>
                            <!-- <a class="mr-xs btn btn-warning btn-xs"><i class="fa fa-pencil-square-o"></i> Setuju</a> -->
                            <!-- <a href="#notif" class="mr-xs btn btn-info btn-xs modal-with-zoom-anim" id="showModal" data-nama="<?php echo e($data->user->name); ?>" data-keperluan="<?php echo e($data->keperluan); ?>" data-mulai="<?php echo e(date('D, d F Y', strtotime( $data->tanggal_start ))); ?>" data-sampai="<?php echo e(date('D, d F Y', strtotime( $data->tanggal_finish ))); ?>">
                                <i class="fa fa-comments-o"></i>
                                Notif
                            </a> -->
                            <!-- <a class="mr-xs btn btn-danger btn-xs"><i class="fa fa-times"></i> Tolak</a> -->
                        </th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
    <!-- End page -->
</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<!-- Specific Page Vendor CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- Specific Page Vendor -->
<script src="<?php echo e(asset('/back')); ?>/vendor/select2/select2.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('last_script'); ?>
<!-- Examples -->
<script src="<?php echo e(asset('/back')); ?>/javascripts/tables/examples.datatables.default.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peminjaman-Sarpras - Copy\resources\views/back/validasi/sudah.blade.php ENDPATH**/ ?>