
<?php $__env->startPush('title', 'Pengguna'); ?>
<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2>Pengguna</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="#!">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Pages</span></li>
                <li><span style="margin-right: 20px;">Pengguna</span></li>
            </ol>

        </div>
    </header>
    <!-- Start page -->
    <section class="panel">
        <header class="panel-heading">
            <div class="panel-actions">
                <a href="#" class="fa fa-caret-down"></a>
                <a href="#" class="fa fa-times"></a>
            </div>

            <h2 class="panel-title">Daftar Pengguna</h2>
        </header>
        <div class="panel-body">
            <?php if(\Session::has('success')): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <strong>Peringatan !!</strong> <?php echo e(\Session::get('success')); ?>

            </div>
            <?php endif; ?>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-lg-offset-4">
                    <!-- <div class="mb-md"> -->
                    <a href="<?php echo e(route('pengguna.create')); ?>" class="btn btn-primary rounded"><i class="fa fa-plus"></i> Create</a>
                    <a href="#modalAnim" class="btn btn-info rounded mr-xl ml-xl modal-with-zoom-anim"><i class="fa fa-cloud-upload"></i> Import</a>
                    <a href="/pengguna/export" class="btn btn-warning rounded"><i class="fa fa-cloud-download"></i> Export</a>
                    <!-- </div> -->
                </div>
            </div>
            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger" style="margin-top: 10px;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php if(session()->has('failures')): ?>
            <table class="table table-bordered table-striped mb-4 mt-4">
                <thead>
                    <tr class="bg-danger">
                        <th>Row</th>
                        <th>Attribute</th>
                        <th>Errors</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = session()->get('failures'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $validation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($validation->row()); ?></td>
                        <td><?php echo e($validation->attribute()); ?></td>
                        <td>
                            <ul>
                                <?php $__currentLoopData = $validation->errors(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($e); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                        <td>
                            <?php echo e($validation->values()[$validation->attribute()]); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>
            <table class="table table-bordered table-striped mb-none" id="datatable-default">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>NIM/NIDN/NIP</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th class="hidden-phone">Level</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($loop->iteration); ?></th>
                        <td><span class="highlight rounded"><?php echo e($data['nim_nidn']); ?></span></td>
                        <td><?php echo e($data['name']); ?></td>
                        <td><?php echo e($data['email']); ?></td>
                        <td class="center"><?php echo e($data['roles']); ?></td>
                        <th width="120px">
                            <a href="<?php echo e(route('pengguna.show', $data['id'])); ?>" class="mr-xs btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="Detail"><i class="fa fa-eye"></i></a>
                            <?php if($data['roles'] != 'BMN'): ?>
                            <a href="<?php echo e(route('pengguna.edit', $data['id'])); ?>" class="mr-xs btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="Ubah"><i class="fa fa-pencil-square-o"></i></a>
                            <a id="delete" data-id="<?php echo e($data['id']); ?>" data-nama="<?php echo e($data['name']); ?>" data-gambar="<?php echo e($data['photo_profile']); ?>" class=" btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="Hapus"><i class="fa fa-trash-o"></i></i></a>
                            <?php endif; ?>
                        </th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
    <!-- End page -->
</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<!-- Specific Page Vendor CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<!-- <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/pnotify/pnotify.custom.css" /> -->
<?php $__env->stopPush(); ?>
<?php $__env->startPush('modals'); ?>
<div id="modalAnim" class="zoom-anim-dialog modal-block modal-block-primary mfp-hide">
    <section class="panel">
        <header class="panel-heading">
            <h2 class="panel-title">Import Data Pengguna</h2>
        </header>
        <form action="<?php echo e(route('pengguna.import')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="panel-body">
                <div class="modal-wrapper">
                    <div class="modal-icon">
                        <i class="fa fa-file-excel-o"></i>
                    </div>
                    <div class="modal-text">
                        <input type="file" class="form-control" name="file" required>
                    </div>
                </div>
            </div>
            <footer class="panel-footer">
                <div class="row">
                    <div class="col-md-12 text-right">
                        <button class="btn btn-primary" type="submit">Confirm</button>
                        <button class="btn btn-default modal-dismiss">Cancel</button>
                    </div>
                </div>
            </footer>
        </form>
    </section>
</div>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
<!-- Specific Page Vendor -->
<script src="<?php echo e(asset('/back')); ?>/vendor/select2/select2.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>
<!-- <script src="<?php echo e(asset('/back')); ?>/vendor/pnotify/pnotify.custom.js"></script> -->
<script>
    $(document).on('click', '#delete', function() {
        var id = $(this).data('id');
        var nama = $(this).data('nama');
        var photo = $(this).data('gambar');

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        swal.fire({
            title: 'Yakin Ingin Hapus?',
            text: "Data " + nama + " kemungkinan terhubung dengan data lain",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya, yakin!',
            cancelButtonText: 'Tidak'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    method: "DELETE",
                    url: "/pengguna/" + id,
                    data: {
                        photo: photo,
                    },
                    success: function(response) {
                        if (response.error_message) {
                            swal.fire({
                                title: 'Error!',
                                text: response.error_message,
                                icon: 'warning',
                                showDenyButton: true,
                                confirmButtonText: 'Ya',
                                denyButtonText: `Nanti`,
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    $.ajax({
                                        method: "DELETE",
                                        url: "/pengguna_delete/" + id,
                                        data: {
                                            photo: photo,
                                        },
                                        success: function(response) {
                                            swal.fire({
                                                icon: 'success',
                                                title: 'Berhasil',
                                                text: response.success_messages
                                            }).then((result) => {
                                                location.reload();
                                            })
                                        },
                                        error: function(xhr) {
                                            swal.fire({
                                                icon: 'error',
                                                title: 'Oops..!',
                                                text: 'Someting went wrong!'
                                            });
                                        }
                                    })
                                } else if (result.isDenied) {
                                    location.reload();
                                }
                            })
                        } else if (response.success_message) {
                            swal.fire({
                                icon: 'success',
                                title: 'Berhasil',
                                text: response.success_message
                            }).then((result) => {
                                location.reload();
                            })
                        }
                    },
                    error: function(xhr) {
                        swal.fire({
                            icon: 'error',
                            title: 'Oops..!',
                            text: 'Someting went wrong!'
                        });
                    }
                });
            }
        })
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('last_script'); ?>
<!-- Examples -->
<script src="<?php echo e(asset('/back')); ?>/javascripts/tables/examples.datatables.default.js"></script>
<script src="<?php echo e(asset('/back')); ?>/javascripts/ui-elements/examples.modals.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nur\Desktop\Peminjaman-Sarpras - Copy\resources\views/back/pengguna/index.blade.php ENDPATH**/ ?>