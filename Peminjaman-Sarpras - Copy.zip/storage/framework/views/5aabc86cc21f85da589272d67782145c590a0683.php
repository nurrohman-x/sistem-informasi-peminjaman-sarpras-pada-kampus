<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldPushContent('title'); ?></title>
    <meta name="keywords" content="HTML5 Admin Template" />
    <meta name="description" content="JSOFT Admin - Responsive HTML5 Template">
    <meta name="author" content="JSOFT.net">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/magnific-popup/magnific-popup.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/bootstrap-datepicker/css/datepicker3.css" />

    <!-- Spesifik vendor  -->
    <?php if(Auth::user()->roles == 'BMN'): ?>
    <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/sweetalert/animate.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/sweetalert/sweetalert2.min.css" />
    <?php endif; ?>

    <?php echo $__env->yieldPushContent('style'); ?>
    <!-- Theme CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="<?php echo e(asset('/back')); ?>/vendor/modernizr/modernizr.js"></script>

</head><?php /**PATH C:\Users\Nur\Desktop\Peminjaman-Sarpras - Copy\resources\views/back/layouts/header.blade.php ENDPATH**/ ?>