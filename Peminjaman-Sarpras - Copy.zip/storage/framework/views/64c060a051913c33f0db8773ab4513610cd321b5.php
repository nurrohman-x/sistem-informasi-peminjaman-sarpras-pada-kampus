
<?php $__env->startPush('title', 'Laporan | Kerusakan'); ?>
<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2>Laporan Kerusakan</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="#!">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Pages</span></li>
                <li><span>Laporan</span></li>
                <li><span style="margin-right: 20px;">Karusakan</span></li>
            </ol>

        </div>
    </header>
    <!-- Start page -->
    <section class="panel">
        <header class="panel-heading">
            <div class="panel-actions">
                <a href="#" class="fa fa-caret-down"></a>
                <a href="#" class="fa fa-times"></a>
            </div>

            <h2 class="panel-title">Daftar Kerusakan</h2>
        </header>
        <div class="panel-body">
            <table class="table table-bordered table-striped mb-none" id="datatable-default">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Pengguna</th>
                        <th>Jumlah</th>
                        <th>Sarpras</th>
                        <th>Keterangan</th>
                        <th>Terakhir Diubah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rusak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($data->user->name); ?></td>
                        <td><?php echo e($data->hilang); ?></td>
                        <td><?php echo e($data->sarpras->nama); ?></td>
                        <td><?php echo e($data->keterangan); ?></td>
                        <td><?php echo e(date('d F Y', strtotime($data->updated_at))); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
    <!-- End page -->
</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<!-- Specific Page Vendor CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- Specific Page Vendor -->
<script src="<?php echo e(asset('/back')); ?>/vendor/select2/select2.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('last_script'); ?>
<!-- Examples -->
<script src="<?php echo e(asset('/back')); ?>/javascripts/tables/examples.datatables.default.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nur\Music\back up\Peminjaman-Sarpras - Copy\resources\views/back/laporan/kerusakan.blade.php ENDPATH**/ ?>