
<?php $__env->startPush('title', 'Laporan | Ketersediaan'); ?>
<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2>Laporan Ketersediaan</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="#!">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Pages</span></li>
                <li><span>Laporan</span></li>
                <li><span style="margin-right: 20px;">Ketersediaan</span></li>
            </ol>

        </div>
    </header>
    <!-- Start page -->
    <section class="panel">
        <header class="panel-heading">
            <div class="panel-actions">
                <a href="#" class="fa fa-caret-down"></a>
                <a href="#" class="fa fa-times"></a>
            </div>

            <h2 class="panel-title">Data Ketersediaan Sarpras</h2>
        </header>
        <div class="panel-body">
            <table class="table table-bordered table-striped mb-none" id="example">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Jenis</th>
                        <th>Nama</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ketersediaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($data->jenis); ?></td>
                        <td><?php echo e($data->nama); ?></td>
                        <td><?php echo e($data->jumlah); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
    <!-- End page -->
</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<!-- Specific Page Vendor CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/datatables/datatables.min.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/datatables/Buttons-2.2.3/css/buttons.bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<!-- Specific Page Vendor -->
<script src="<?php echo e(asset('/back')); ?>/vendor/select2/select2.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/datatables/datatables.min.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>

<script src="<?php echo e(asset('/back')); ?>/vendor/datatables/Buttons-2.2.3/js/dataTables.buttons.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/datatables/Buttons-2.2.3/js/buttons.bootstrap.min.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/datatables/JSZip-2.5.0/jszip.min.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/datatables/pdfmake-0.1.36/pdfmake.min.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/datatables/Buttons-2.2.3/js/buttons.html5.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/datatables/Buttons-2.2.3/js/buttons.print.min.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/datatables/Buttons-2.2.3/js/buttons.colVis.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('last_script'); ?>
<script>
    $(document).ready(function() {
        var table = $('#example').DataTable({
            lengthChange: false,
            buttons: ['copy', 'excel', 'pdf', 'colvis']
        });

        table.buttons().container()
            .appendTo('#example_wrapper .col-sm-6:eq(0)');

    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nur\Desktop\Peminjaman-Sarpras - Copy\resources\views/back/laporan/ketersediaan.blade.php ENDPATH**/ ?>