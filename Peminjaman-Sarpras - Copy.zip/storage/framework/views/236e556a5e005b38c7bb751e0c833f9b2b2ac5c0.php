<?php $__currentLoopData = $sarpras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-3 mt-xl">
    <div class="panel-body">
        <a class="image-popup-no-margins" href="<?php echo e(url('/storage/'. $data->photo)); ?>">
            <img class="img-responsive" src="<?php echo e(url('/storage/'. $data->photo)); ?>" style="height: 16rem; width:27rem;">
        </a>
        <h4 class="text-dark"><?php echo e($data->nama); ?></h4>
        <h5 class="text-bold"><?php echo e($data->jumlah); ?></h5>
        <div style="margin: auto; width: 60%;">
            <div data-plugin-spinner data-plugin-options='{ "value":0, "step": 1, "min": 0, "max": <?php echo e($data->jumlah); ?> }'>
                <div class="input-group">
                    <div class="spinner-buttons input-group-btn">
                        <button type="button" class="btn btn-default spinner-down">
                            <i class="fa fa-minus"></i>
                        </button>
                    </div>
                    <input type="hidden" id="sarpras_id" value="<?php echo e($data->id); ?>">
                    <input type="hidden" id="validasi_id" value="<?php echo e($id); ?>">
                    <input type="text" class="spinner-input form-control text-center" readonly>
                    <div class="spinner-buttons input-group-btn">
                        <button type="button" class="btn btn-default spinner-up">
                            <i class="fa fa-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div style="margin: auto; width: 45%;">
            <button class="btn btn-primary addToDraf mt-xl">Add to Draf</button>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\Nur\Music\back up\Peminjaman-Sarpras - Copy\resources\views/back/validasi/list_sarpras.blade.php ENDPATH**/ ?>