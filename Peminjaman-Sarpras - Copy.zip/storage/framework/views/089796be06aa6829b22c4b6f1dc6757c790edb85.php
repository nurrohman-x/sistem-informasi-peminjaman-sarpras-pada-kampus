
<?php $__env->startPush('title', 'Bot WhatsApp'); ?>
<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2>Bot</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="#!">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Pages</span></li>
                <li><span style="margin-right: 20px;">Bot</span></li>
            </ol>

        </div>
    </header>
    <!-- Start page -->
    <section class="panel">
        <header class="panel-heading">
            <div class="panel-actions">
                <a href="#" class="fa fa-caret-down"></a>
                <a href="#" class="fa fa-times"></a>
            </div>

            <h2 class="panel-title">Daftar Response Bot WhatsApp</h2>
        </header>
        <div class="panel-body">
            <?php if(\Session::has('error')): ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <strong>Peringatan !!</strong> <?php echo e(\Session::get('error')); ?>

            </div>
            <?php endif; ?>
            <?php if(\Session::has('success')): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <strong>Peringatan !!</strong> <?php echo e(\Session::get('success')); ?>

            </div>
            <?php endif; ?>
            <a href="#modalCreate" class="btn btn-primary rounded mb-xl modal-with-zoom-anim"><i class="fa fa-plus"></i> Buat</a>
            <table class="table table-bordered table-striped mb-none" id="datatable-default">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Diterima</th>
                        <th>Response</th>
                        <th class="center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($data->received); ?></td>
                        <td><?php echo e($data->send); ?></td>
                        <th width="100px !important">
                            <a href="#modalDetail" id="detail" data-received="<?php echo e($data->received); ?>" data-send="<?php echo e($data->send); ?>" class="mr-xs btn btn-primary btn-sm modal-with-zoom-anim" data-toggle="tooltip" data-placement="top" title="Detail"><i class="fa fa-eye"></i></a>
                            <a href="#modalEdit" id="edit" data-id="<?php echo e($data->id); ?>" data-received="<?php echo e($data->received); ?>" data-send="<?php echo e($data->send); ?>" class="mr-xs btn btn-warning btn-sm modal-with-zoom-anim" data-toggle="tooltip" data-placement="top" title="Ubah"><i class="fa fa-pencil-square-o"></i></a>
                            <form onclick="return confirm('Yakin ingin hapus ini?')" action="<?php echo e(route('bot.destroy', $data->id)); ?>" method="post" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" style="width: 34px;" class="mr-xs mt-xs btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="Hapus">
                                    <i class="fa fa-trash-o"></i>
                                </button>
                            </form>
                        </th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
    <!-- End page -->
</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<!-- Specific Page Vendor CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/css/datatables.css" />
<!-- <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/pnotify/pnotify.custom.css" /> -->
<?php $__env->stopPush(); ?>
<?php $__env->startPush('modals'); ?>
<div id="modalCreate" class="zoom-anim-dialog modal-block modal-block-primary mfp-hide">
    <section class="panel">
        <header class="panel-heading">
            <h2 class="panel-title">Buat Response Bot</h2>
        </header>
        <form action="<?php echo e(route('bot.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="panel-body">
                <div class="modal-wrapper">
                    <div class="modal-text">
                        <div class="form-group <?php $__errorArgs = ['received'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-sm-4 control-label" for="received">Diterima</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control input-sm" name="received" id="received">
                                <?php $__errorArgs = ['received'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group <?php $__errorArgs = ['response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-sm-4 control-label" for="kirim">Response</label>
                            <div class="col-sm-8">
                                <textarea name="response" id="response" rows="5" class="form-control"></textarea>
                                <!-- <input type="text" class="form-control input-sm" name="response" id="response"> -->
                                <?php $__errorArgs = ['response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="panel-footer">
                <div class="row">
                    <div class="col-md-12 text-right">
                        <button class="btn btn-primary" type="submit">Confirm</button>
                        <button class="btn btn-default modal-dismiss">Cancel</button>
                    </div>
                </div>
            </footer>
        </form>
    </section>
</div>
<div id="modalDetail" class="zoom-anim-dialog modal-block modal-block-primary mfp-hide">
    <section class="panel">
        <header class="panel-heading">
            <h2 class="panel-title">Detail Response Bot</h2>
        </header>
        <div class="panel-body">
            <div class="modal-wrapper">
                <div class="modal-text">
                    <div class="form-group <?php $__errorArgs = ['received'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label class="col-sm-4 control-label" for="received">Diterima</label>
                        <div class="col-sm-8">
                            <p id="received"></p>
                        </div>
                    </div>
                    <div class="form-group <?php $__errorArgs = ['response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label class="col-sm-4 control-label" for="kirim">Response</label>
                        <div class="col-sm-8">
                            <p id="send"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="panel-footer">
            <div class="row">
                <div class="col-md-12 text-right">
                    <button class="btn btn-default modal-dismiss">Tutup</button>
                </div>
            </div>
        </footer>
    </section>
</div>
<div id="modalEdit" class="zoom-anim-dialog modal-block modal-block-primary mfp-hide">
    <section class="panel">
        <header class="panel-heading">
            <h2 class="panel-title">Detail Response Bot</h2>
        </header>
        <form id="formUpdate" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="panel-body">
                <div class="modal-wrapper">
                    <div class="modal-text">
                        <div class="form-group <?php $__errorArgs = ['received'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-sm-4 control-label" for="received">Diterima</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control input-sm" name="received" id="received">
                                <?php $__errorArgs = ['received'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group <?php $__errorArgs = ['response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-sm-4 control-label" for="kirim">Response</label>
                            <div class="col-sm-8">
                                <textarea name="response" id="response" rows="5" class="form-control"></textarea>

                                <!-- <input type="text" class="form-control input-sm" name="response" id="response"> -->
                                <?php $__errorArgs = ['response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="panel-footer">
                <div class="row">
                    <div class="col-md-12 text-right">
                        <button class="btn btn-primary" type="submit">Confirm</button>
                        <button class="btn btn-default modal-dismiss">Tutup</button>
                    </div>
                </div>
            </footer>
        </form>
    </section>
</div>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
<!-- Specific Page Vendor -->
<script src="<?php echo e(asset('/back')); ?>/vendor/select2/select2.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>
<script>
    $(document).on('click', '#detail', function() {
        var received = $(this).data('received');
        var send = $(this).data('send');

        $('#received').text(received);
        $('#send').text(send);
    });
    $(document).on('click', '#edit', function() {
        var id = $(this).data('id');
        var received = $(this).data('received');
        var send = $(this).data('send');

        $('#formUpdate').attr('action', 'bot/' + id);
        $('#received').val(received);
        $('#response').val(send);
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('last_script'); ?>
<!-- Examples -->
<script src="<?php echo e(asset('/back')); ?>/javascripts/tables/examples.datatables.default.js"></script>
<script src="<?php echo e(asset('/back')); ?>/javascripts/ui-elements/examples.modals.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nur\Desktop\Peminjaman-Sarpras - Copy\resources\views/back/bot/index.blade.php ENDPATH**/ ?>