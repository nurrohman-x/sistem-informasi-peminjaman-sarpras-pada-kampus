
<?php $__env->startPush('title', 'Pengembalian'); ?>
<?php $__env->startSection('content'); ?>
<section class="sec-product-detail bg0 p-t-65 p-b-60">
    <div class="container">
        <h4 class="text-center text-uppercase m-b-22">Daftar Pengembalian</h4>
        <table class="table table-striped table-hover table-bordered" id="example-1">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Keperluan</th>
                    <th>Tanggal Ambil</th>
                    <th>Tanggal Kembali</th>
                    <th>Penilaian</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pengembalian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><a href="<?php echo e(route('pengembalian.show', $data->id)); ?>" style="color: #7280e0;"><?php echo e($data->validasi->keperluan); ?></a></td>
                    <td><?php echo e(date('d F Y', strtotime( $data->date_ambil ))); ?></td>
                    <td><?php echo e(date('d F Y', strtotime( $data->date_kembali ))); ?></td>
                    <td id="rate-rating">
                        <?php if($data->rating->penilaian == 1): ?>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star-o" aria-hidden="true"></i>
                        <i class="fa fa-star-o" aria-hidden="true"></i>
                        <i class="fa fa-star-o" aria-hidden="true"></i>
                        <i class="fa fa-star-o" aria-hidden="true"></i>
                        <?php elseif($data->rating->penilaian == 2): ?>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star-o" aria-hidden="true"></i>
                        <i class="fa fa-star-o" aria-hidden="true"></i>
                        <i class="fa fa-star-o" aria-hidden="true"></i>
                        <?php elseif($data->rating->penilaian == 3): ?>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star-o" aria-hidden="true"></i>
                        <i class="fa fa-star-o" aria-hidden="true"></i>
                        <?php elseif($data->rating->penilaian == 4): ?>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star-o" aria-hidden="true"></i>
                        <?php elseif($data->rating->penilaian == 5): ?>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/front')); ?>/vendor/datatables/dataTables.bootstrap4.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function() {
        $('#example-1').DataTable({
            "pagingType": "simple_numbers",
            oLanguage: {
                oPaginate: {
                    sNext: '<i class="zmdi zmdi-skip-next" style="font-size: 19px;"></i>',
                    sPrevious: '<i class="zmdi zmdi-skip-previous" style="font-size: 19px;"></i>'
                }
            },
            "lengthMenu": [
                [5, 10, 25, 50, -1],
                [5, 10, 25, 50, "All"]
            ]
        });
        $('.dataTables_filter').addClass('pull-right');
        $('.dataTables_info').addClass('pull-left');
    });
</script>
<script src="<?php echo e(asset('/front')); ?>/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('/front')); ?>/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.layouts.index_', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nur\Desktop\Peminjaman-Sarpras - Copy\resources\views/front/module/pengembalian.blade.php ENDPATH**/ ?>