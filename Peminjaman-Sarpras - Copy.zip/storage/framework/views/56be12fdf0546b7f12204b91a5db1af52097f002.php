
<?php $__env->startPush('title', 'Edit | Sarpras'); ?>
<?php $__env->startSection('content'); ?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2>Edit Sarpras</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="#!">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Pages</span></li>
                <li><span>Sarpras</span></li>
                <li><span style="margin-right: 20px;">Edit</span></li>
            </ol>
        </div>
    </header>
    <!-- Start page -->
    <div class="row">
        <div class="col-xs-6">
            <section class="panel">
                <header class="panel-heading">
                    <div class="panel-actions">
                        <a href="#" class="fa fa-caret-down"></a>
                        <a href="#" class="fa fa-times"></a>
                    </div>

                    <h2 class="panel-title">Select Replacement</h2>
                </header>
                <div class="panel-body">
                    <form class="form-horizontal form-bordered" action="<?php echo e(route('sarpras.update', $sarpras->id)); ?>" method="POST" id="formEdit" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="form-group <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-md-3 control-label">Jenis<span class="required">*</span></label>
                            <div class="col-md-8">
                                <select data-plugin-selectTwo class="form-control" id="jenis" name="jenis" onchange="showKategori(this)">
                                    <option value="Ruangan" <?php echo e($sarpras->jenis == 'Ruangan' ? 'selected' : null); ?>>Ruangan</option>
                                    <option value="Barang" <?php echo e($sarpras->jenis == 'Barang' ? 'selected' : null); ?>>Barang</option>
                                </select>
                                <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <?php
                        $pecah_string = explode(", ", $sarpras->kategori);
                        ?>
                        <div class="form-group" id="barang">
                            <label class="col-md-3 control-label">Kategori</label>
                            <div class="col-md-6">
                                <select class="form-control" multiple="multiple" name="kategori_brg[]" data-plugin-multiselect id="ms_example0">
                                    <option value="elektronik" <?php $__currentLoopData = $pecah_string; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($data == 'elektronik' ? 'selected' : null); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>Elektronik</option>
                                    <option value="mebel" <?php $__currentLoopData = $pecah_string; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($data == 'mebel' ? 'selected' : null); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>Mebel</option>
                                    <option value="lainnya" <?php $__currentLoopData = $pecah_string; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($data == 'lainnya' ? 'selected' : null); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>Lainnya</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group" id="ruangan">
                            <label class="col-md-3 control-label">Kategori</label>
                            <div class="col-md-6">
                                <select class="form-control" multiple="multiple" name="kategori_rgn[]" data-plugin-multiselect id="ms_example0">
                                    <option value="kelas" <?php $__currentLoopData = $pecah_string; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($data == 'kelas' ? 'selected' : null); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>Kelas</option>
                                    <option value="lainnya" <?php $__currentLoopData = $pecah_string; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($data == 'lainnya' ? 'selected' : null); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>Lainnya</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-md-3 control-label" for="nama">Nama<span class="required">*</span></label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" id="nama" value="<?php echo e($sarpras->nama); ?>" name="nama">
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-md-3 control-label" for="deskripsi">Deskripsi<span class="required">*</span></label>
                            <div class="col-md-8">
                                <textarea name="deskripsi" id="deskripsi" rows="5" class="form-control"><?php echo e($sarpras->deskripsi); ?></textarea>
                                <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label class="col-md-3 control-label" for="Photo">Photo<span class="required">*</span></label>
                            <div class="col-md-8">
                                <input type="hidden" name="old_photo" value="<?php echo e($sarpras->photo); ?>">
                                <input type="file" class="form-control" id="Photo" name="photo" onchange="previewImage(this)">
                                <img src="<?php echo e(url('/storage/sarpras/'. $sarpras->photo)); ?>" id="preview_sarpras" class="rounded img-responsive" style="width: 35vh; margin-top:10px;">
                                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="has-error" role="alert">
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="panel-footer">
                    <div class="row">
                        <div class="col-md-9 col-md-offset-3">
                            <button onclick="document.getElementById('formEdit').submit()" class="btn btn-primary">Submit</button>
                            <button onclick="document.getElementById('formEdit').reset()" class="btn btn-default">Reset</button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <!-- End page -->
</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<!-- Specific Page Vendor CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/select2/select2.css" />
<link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-validation/jquery.validate.js"></script>
<!-- Specific Page Vendor -->
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/select2/select2.js"></script>
<script src="<?php echo e(asset('/back')); ?>/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
<script>
    function previewImage(input) {
        var file = $("input[type=file]").get(0).files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function() {
                $('#preview_sarpras').attr("src", reader.result);
            }
            reader.readAsDataURL(file);
        }
    }
    if ($('#jenis').val() == 'Ruangan') {
        $("#barang").hide();
    } else if ($('#jenis').val() == 'Barang') {
        $("#ruangan").hide();
    }

    function showKategori(elem) {
        if (elem.value == 'Ruangan') {
            $("#ruangan").show();
            $("#barang").hide();
        } else if (elem.value == 'Barang') {
            $('#barang').show();
            $("#ruangan").hide();
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('last_script'); ?>
<!-- Examples -->
<script src="<?php echo e(asset('/back')); ?>/javascripts/forms/examples.advanced.form.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('back.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nur\Music\back up\Peminjaman-Sarpras - Copy\resources\views/back/sarpras/edit.blade.php ENDPATH**/ ?>