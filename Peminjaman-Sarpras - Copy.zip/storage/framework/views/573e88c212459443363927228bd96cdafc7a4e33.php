<table class="table table-bordered table-striped mb-none" id="datatable-default">
    <thead>
        <tr>
            <th>#</th>
            <th>Nama</th>
            <th>Tanggal</th>
            <th class="hidden-phone">Jumlah</th>
            <th class="center">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $sarpras_keluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($loop->iteration); ?></th>
            <td><?php echo e($data->sarpras->nama); ?></td>
            <td><?php echo e(date('l, d F Y', strtotime($data->tanggal))); ?></td>
            <td class="center"><?php echo e($data->jumlah); ?></td>
            <th width="125px">
                <a href="<?php echo e(route('sarpras_keluar.show', $data->id)); ?>" class="mr-xs btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="Detail"><i class="fa fa-eye"></i></a>
                <a id="edit" data-id="<?php echo e($data->id); ?>" data-tanggal="<?php echo e($data->tanggal); ?>" data-jumlah="<?php echo e($data->jumlah); ?>" data-keterangan="<?php echo e($data->keterangan); ?>" data-sarpras_id="<?php echo e($data->sarpras_id); ?>" data-nama="<?php echo e($data->sarpras->nama); ?>" data-img="<?php echo e($data->sarpras->photo); ?>" data-toggle="modal" data-target="#exampleModal" class="mr-xs btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="Ubah"><i class="fa fa-pencil-square-o"></i></a>
                <!-- <form onclick="return confirm('Yakin ingin hapus ini?')" action="<?php echo e(route('sarpras_keluar.destroy', $data->id)); ?>" method="post" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="Hapus">
                        <i class="fa fa-trash-o"></i>
                    </button>
                </form> -->
                <a id="delete" data-id="<?php echo e($data->id); ?>" data-nama="<?php echo e($data->nama); ?>" data-gambar="<?php echo e($data->photo); ?>" style="width: 34px;" class="mt-xs btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="Hapus"><i class="fa fa-trash-o"></i></i></a>
            </th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\Nur\Desktop\Peminjaman-Sarpras - Copy\resources\views/back/sarpras_keluar/table.blade.php ENDPATH**/ ?>