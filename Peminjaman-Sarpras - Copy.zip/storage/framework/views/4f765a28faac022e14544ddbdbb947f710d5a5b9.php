<html>

<head>
    <title><?php echo e($validasi->user->name); ?> - Draft Print</title>
    <!-- Web Fonts  -->
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet" type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/vendor/bootstrap/css/bootstrap.css" />

    <!-- Invoice Print Style -->
    <link rel="stylesheet" href="<?php echo e(asset('/back')); ?>/stylesheets/invoice-print.css" />
</head>

<body>
    <div class="invoice">
        <header class="clearfix">
            <div class="row">
                <div class="col-sm-6 mt-md">
                    <!-- <h2 class="h2 mt-none mb-sm text-dark text-bold">Draft</h2> -->
                    <!-- <h4 class="h4 m-none text-dark text-bold">#76598345</h4> -->

                    <div class="m-t-15 ">
                        <img src="<?php echo e(asset('/back')); ?>/images/invoice-logo.png" alt="OKLER Themes" />
                    </div>
                </div>
                <div class="col-sm-6 text-right mt-md mb-md">
                    <address class="ib mr-xlg">
                        Jl. Lingkar Maskumambang
                        <br />
                        No.1, Sukorame, Kec. Mojoroto, Jawa Timur
                        <br />
                        Telepon: 0896-0900-4444
                        <br />
                        okler@okler.net
                    </address>
                </div>
            </div>
        </header>
        <div class="bill-info">
            <div class="row">
                <div class="col-md-6">
                    <div class="bill-to">
                        <p class="h5 mb-xs text-dark text-semibold">Ke:</p>
                        <address>
                            <?php echo e($validasi->user->name); ?>

                            <br />
                            Ds. <?php echo e($validasi->user->desa); ?>, Kota <?php echo e($validasi->user->kota); ?>

                            <br />
                            Telepon: <?php echo e($validasi->user->no_telp); ?>

                            <br />
                            <?php echo e($validasi->user->email); ?>

                        </address>
                        <p class="h5 mb-xs text-dark text-semibold">Keperluan:</p>
                        <address>
                            <?php echo e($validasi->keperluan); ?>

                        </address>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="bill-data text-right">
                        <p class="mb-none">
                            <span class="text-dark">Mulai Tanggal:</span>
                            <span class="value"><?php echo e(date('H:i d/m/Y', strtotime( $validasi->tanggal_start))); ?></span>
                        </p>
                        <p class="mb-none">
                            <span class="text-dark">Sampai Tanggal:</span>
                            <span class="value"><?php echo e(date('H:i d/m/Y', strtotime( $validasi->tanggal_finish))); ?></span>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table invoice-items">
                <thead>
                    <tr class="h4 text-dark">
                        <th id="cell-id" class="text-semibold">#</th>
                        <th id="cell-item" class="text-semibold">Jenis</th>
                        <th id="cell-desc" class="text-semibold">Nama</th>
                        <th id="cell-price" class="text-center text-semibold">Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $validasi->draft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="text-semibold text-dark"><?php echo e($data->sarpras->jenis); ?></td>
                        <td><?php echo e($data->sarpras->nama); ?></td>
                        <td class="text-center"><?php echo e($data->qty); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="invoice-summary">
            <?php

            use SimpleSoftwareIO\QrCode\Facades\QrCode;

            $qr_code = QrCode::generate($validasi->id . ' ' . $validasi->keperluan . $validasi->tanggal_start);

            ?>
            <div class="text-right">
                <?php echo $qr_code; ?>

            </div>
        </div>
    </div>
    <script script>
        window.print();
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\Peminjaman-Sarpras - Copy\resources\views/print.blade.php ENDPATH**/ ?>