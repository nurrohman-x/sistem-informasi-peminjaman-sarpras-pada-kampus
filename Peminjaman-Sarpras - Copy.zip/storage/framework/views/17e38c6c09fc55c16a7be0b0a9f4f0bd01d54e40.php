
<?php $__env->startPush('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content page -->
<section class="bg0 p-t-75 p-b-120">
    <div class="container">
        <div class="profile-header">
            <div class="profile-img">
                <?php if(Auth::user()->photo_profile): ?>
                <img src="<?php echo e(url('/storage/'. Auth::user()->photo_profile)); ?>" width="200" alt="">
                <?php else: ?>
                <img src="https://ui-avatars.com/api/?name=<?php echo e(Auth::user()->name); ?>" width="200" alt="">
                <?php endif; ?>
            </div>
            <div class="profile-nav-info">
                <h3 class="user-name"><?php echo e(Auth::user()->name); ?></h3>
                <div class="address">
                    <p class="state"><?php echo e(Auth::user()->desa); ?>,</p>
                    <span class="country"><?php echo e(Auth::user()->kota); ?></span>
                </div>
            </div>
            <!-- <div class="profile-option">
                <div class="notification">
                    <i class="lnr lnr-alarm"></i>
                    <span class="alert-message">1</span>
                </div>
            </div> -->
        </div>
        <div class="main-bd">
            <div class="left-side">
                <div class="profile-side">
                    <div class="flex-w w-full p-b-18">
                        <span class="fs-18 txt-center cl5 p-t-2 size-211">
                            <span class="lnr lnr-envelope"></span>
                        </span>

                        <div class="size-212 p-t-2">
                            <span class="mtext-110 cl2">
                                Email
                            </span>

                            <p class="stext-115 cl6 size-213 p-t-8">
                                <?php echo e(Auth::user()->email); ?>

                            </p>
                        </div>
                    </div>
                    <div class="flex-w w-full p-b-18">
                        <span class="fs-18 txt-center cl5 p-t-2 size-211">
                            <span class="lnr lnr-license"></span>
                        </span>

                        <div class="size-212 p-t-2">
                            <span class="mtext-110 cl2">
                                NIM / NIDN
                            </span>

                            <p class="stext-115 cl6 size-213 p-t-8">
                                <?php echo e(Auth::user()->nim_nidn); ?>

                            </p>
                        </div>
                    </div>
                    <div class="flex-w w-full p-b-18">
                        <span class="fs-18 txt-center cl5 p-t-2 size-211">
                            <span class="lnr lnr-phone-handset"></span>
                        </span>

                        <div class="size-212 p-t-2">
                            <span class="mtext-110 cl2">
                                No Telp
                            </span>

                            <p class="stext-115 cl6 size-213 p-t-8">
                                <?php echo e(Auth::user()->no_telp); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="right-side">
                <div class="nav-side">
                    <ul>
                        <li onclick="tabs(0)" class="user-post active">Permohonan</li>
                        <li onclick="tabs(1)" class="user-review">Peminjaman</li>
                        <li onclick="tabs(2)" class="user-setting">Pengembalian</li>
                    </ul>
                </div>
                <div class="profile-body">
                    <div class="profile-posts tab">
                        <h4 class="mtext-112 cl2 p-b-27">Daftar Permohonan Pinjaman</h4>
                    </div>
                    <div class="profile-review tab">
                        <h4 class="mtext-112 cl2 p-b-27">Daftar Peminjaman</h4>
                    </div>
                    <div class="profile-setting tab">
                        <h4 class="mtext-112 cl2 p-b-27">Daftar Pengembalian</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.layouts.index_', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peminjaman-Sarpras - Copy\resources\views/front/profile/show.blade.php ENDPATH**/ ?>