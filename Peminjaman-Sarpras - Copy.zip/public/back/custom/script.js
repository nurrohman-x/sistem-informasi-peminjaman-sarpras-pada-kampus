function ShowChat() {
	$('#Chat').toggleClass('active');
}